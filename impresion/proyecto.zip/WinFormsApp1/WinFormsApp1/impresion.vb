﻿Imports Microsoft.Office.Interop

Public Class impresion
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        Dim xlWorkBook As Excel.Workbook
        Dim xlWorkSheet As Excel.Worksheet

        Dim xlApp As Excel.Application
        xlApp = New Excel.Application
        xlWorkBook = xlApp.Workbooks.Add()
        xlWorkSheet = CType(xlWorkBook.Sheets("Hoja1"), Excel.Worksheet)

        'Personaliza el tipo de letra.
        xlWorkSheet.Range("B2:F24").Font.Name = "Arial"

        xlWorkSheet.Range("B2:F24").RowHeight = 100 ' Establece la altura de la fila a 30 puntos

        'Personaliza el tamaño de letra de las celdas.
        xlWorkSheet.Range("B2").Font.Size = 72
        xlWorkSheet.Range("D2:F8").Font.Size = 10
        xlWorkSheet.Range("B9:F23").Font.Size = 10
        xlWorkSheet.Range("B4:F24").Font.Size = 12
        xlWorkSheet.Range("D4:F4").Font.Size = 22
        ' Cambiar el color de letra de¡ las celdas

        xlWorkSheet.Range("A1:L24").Interior.Color = Color.White


        xlWorkSheet.Range("B2:C8").Font.Name = "Astrolab" ' Establece la fuente a Arial


        xlWorkSheet.Range("B2:F10").Font.Color = Color.White

        xlWorkSheet.Range("D3:F3").Font.Color = Color.FromArgb(83, 97, 98)

        'EMPRESA JK		
        xlWorkSheet.Range("D4:F4").Font.Color = Color.FromArgb(67, 116, 255)

        xlWorkSheet.Range("D5:F5").Font.Color = Color.FromArgb(83, 97, 98)





        xlWorkSheet.Range("B2:C8").Font.Color = Color.FromArgb(67, 116, 255)

        xlWorkSheet.Range("D6:F6").Font.Color = Color.FromArgb(83, 97, 98)
        xlWorkSheet.Range("D7:F7").Font.Color = Color.FromArgb(83, 97, 98)
        xlWorkSheet.Range("B11:B16").Font.Color = Color.White
        xlWorkSheet.Range("B17:F17").Font.Color = Color.White
        xlWorkSheet.Range("B19:F21").Font.Color = Color.White
        xlWorkSheet.Range("B23:F24").Font.Color = Color.White
        ' Hace que el texto sea negrita.
        xlWorkSheet.Range("B2:F8").Font.Bold = True
        xlWorkSheet.Range("B9:B16").Font.Bold = True
        xlWorkSheet.Range("C9:F10").Font.Bold = True
        xlWorkSheet.Range("B17:F17").Font.Bold = True
        xlWorkSheet.Range("B19:F19").Font.Bold = True
        xlWorkSheet.Range("B20").Font.Bold = True
        xlWorkSheet.Range("B21:F21").Font.Bold = True
        xlWorkSheet.Range("B23").Font.Bold = True
        xlWorkSheet.Range("B24:F24").Font.Bold = True
        ' Establecer el ancho y la altura de las celdas
        'columnas
        xlWorkSheet.Range("B1").ColumnWidth = 28.57
        xlWorkSheet.Range("C1").ColumnWidth = 28.14
        xlWorkSheet.Range("D1").ColumnWidth = 14.14
        xlWorkSheet.Range("E1").ColumnWidth = 31.43
        xlWorkSheet.Range("F1").ColumnWidth = 22.57
        'filas
        xlWorkSheet.Range("G2:G16").RowHeight = 16
        xlWorkSheet.Range("G4").RowHeight = 36
        xlWorkSheet.Range("G17").RowHeight = 23
        xlWorkSheet.Range("G18").RowHeight = 52
        xlWorkSheet.Range("G20:G23").RowHeight = 19
        xlWorkSheet.Range("G19").RowHeight = 50
        ' Personaliza el color de  fondo.
        'color black
        xlWorkSheet.Range("B2:C8").Interior.Color = Color.White
        xlWorkSheet.Range("D2:F2").Interior.Color = Color.FromArgb(67, 116, 255)
        xlWorkSheet.Range("D4:F4").Interior.Color = Color.FromArgb(67, 116, 255)
        xlWorkSheet.Range("D6:F6").Interior.Color = Color.FromArgb(67, 116, 255)
        xlWorkSheet.Range("D8:F8").Interior.Color = Color.FromArgb(67, 116, 255)
        xlWorkSheet.Range("D10:F10").Interior.Color = Color.FromArgb(67, 116, 255)
        xlWorkSheet.Range("B11:B16").Interior.Color = Color.FromArgb(67, 116, 255)
        xlWorkSheet.Range("B19:F19").Interior.Color = Color.FromArgb(67, 116, 255)
        'color darkgray
        xlWorkSheet.Range("D3:F3").Interior.Color = Color.White
        xlWorkSheet.Range("D5:F5").Interior.Color = Color.White
        xlWorkSheet.Range("D7:F7").Interior.Color = Color.White

        xlWorkSheet.Range("D2:F8").Interior.Color = Color.White


        xlWorkSheet.Range("B9:B10").Interior.Color = Color.DarkGray
        xlWorkSheet.Range("D9").Interior.Color = Color.DarkGray
        xlWorkSheet.Range("B17:F17").Interior.Color = Color.FromArgb(67, 116, 255)
        xlWorkSheet.Range("B21:F21").Interior.Color = Color.White
        xlWorkSheet.Range("B20").Interior.Color = Color.White
        xlWorkSheet.Range("B23").Interior.Color = Color.White
        'color gray
        xlWorkSheet.Range("B9:F10").Interior.Color = Color.FromArgb(67, 116, 255)
        xlWorkSheet.Range("C9:F10").Interior.Color = Color.White
        xlWorkSheet.Range("C9:F10").Font.Color = Color.FromArgb(83, 97, 98)



        xlWorkSheet.Range("C20:F20").Interior.Color = Color.White
        xlWorkSheet.Range("C23:F23").Interior.Color = Color.White
        'color white
        xlWorkSheet.Range("D11:F11").Interior.Color = Color.White
        xlWorkSheet.Range("D13:F13").Interior.Color = Color.White
        xlWorkSheet.Range("D15:F15").Interior.Color = Color.White
        xlWorkSheet.Range("B18:F18").Interior.Color = Color.White
        'color smoke white
        xlWorkSheet.Range("D12:F12").Interior.Color = Color.White
        xlWorkSheet.Range("D14:F14").Interior.Color = Color.White
        xlWorkSheet.Range("D16:F16").Interior.Color = Color.White
        xlWorkSheet.Range("B22:F22").Interior.Color = Color.White



        'LABELS DE LOS DATOS TIKETS
        xlWorkSheet.Range("B9:B16").Font.Color = Color.FromArgb(83, 97, 98)

        xlWorkSheet.Range("B9:B16").Interior.Color = Color.White


        ' Agrega datos a la hoja de trabajo.           Formato de tabla
        'fila , columna
        '--------------------------------------------------
        'Logo JK
        xlWorkSheet.Cells(2, 2) = "JK"
        '--------------------------------------------------------------
        'info de RUC
        'fila, columna

        xlWorkSheet.Cells(3, 4) = "Comprobante de Factura Electronica"
        xlWorkSheet.Cells(4, 4) = "EMPRESA JK"
        xlWorkSheet.Cells(5, 4) = "R.U.C 000000-0000-000000"
        xlWorkSheet.Cells(6, 4) = "DAVID, AV. 3RA, ENTRE AV. OBALDIA Y AV. BALBOA"
        xlWorkSheet.Cells(7, 4) = "Telefono: 665-1412  o 923-9234"
        xlWorkSheet.Cells(8, 4) = "FACTURA"
        '--------------------------------------------------------------
        'info del cliente
        'fila, columna



        xlWorkSheet.Cells(9, 2) = "Usuario"
        xlWorkSheet.Cells(11, 2) = "No.Usuario"
        xlWorkSheet.Cells(12, 2) = "Equipo"
        xlWorkSheet.Cells(13, 2) = "Tipo de Soporte"
        xlWorkSheet.Cells(14, 2) = "Estado"
        xlWorkSheet.Cells(15, 2) = "Fecha de Inicio"
        xlWorkSheet.Cells(16, 2) = "Fecha de Finalización"
        '-------------------------------------------------------------
        'tabla de costos
        'fila, columna
        xlWorkSheet.Cells(9, 4) = "No.Ticket"
        xlWorkSheet.Cells(10, 4) = "Cantidad"
        xlWorkSheet.Cells(10, 5) = "Descripcion"
        xlWorkSheet.Cells(10, 6) = "Precio"
        xlWorkSheet.Cells(14, 5) = "Sub total"
        xlWorkSheet.Cells(15, 5) = "Impuesto (7%)"
        xlWorkSheet.Cells(16, 5) = "Total"
        '----------------------------------------------------------
        'informacion adicional
        xlWorkSheet.Cells(17, 2) = "Observacion de Costos Extras"

        xlWorkSheet.Cells(19, 2) = "GRACIAS POR PREFERIRNOS"
        '*********************************************************
        'centrar y combinar 
        ' Combinar celdas
        'logo
        xlWorkSheet.Range("B2:C8").Merge()
        'encabezado
        xlWorkSheet.Range("D2:F2").Merge()
        xlWorkSheet.Range("D3:F3").Merge()
        xlWorkSheet.Range("D4:F4").Merge()
        xlWorkSheet.Range("D5:F5").Merge()
        xlWorkSheet.Range("D6:F6").Merge()
        xlWorkSheet.Range("D7:F7").Merge()
        xlWorkSheet.Range("D8:F8").Merge()
        'datos de cliente
        xlWorkSheet.Range("B9:B10").Merge()
        xlWorkSheet.Range("C9:C10").Merge()
        'Tabla Precios
        xlWorkSheet.Range("E9:F9").Merge()
        'otros Datos
        xlWorkSheet.Range("B17:F17").Merge()
        xlWorkSheet.Range("B18:F18").Merge()
        xlWorkSheet.Range("B19:F19").Merge()
        xlWorkSheet.Range("C20:F20").Merge()
        xlWorkSheet.Range("C21:F21").Merge()
        xlWorkSheet.Range("C22:F22").Merge()
        xlWorkSheet.Range("C23:F23").Merge()
        xlWorkSheet.Range("B24:F24").Merge()


        ' Centra el contenido de cada celda.
        xlWorkSheet.Range("B2:F8").HorizontalAlignment = Excel.Constants.xlCenter
        xlWorkSheet.Range("B9:B16").HorizontalAlignment = Excel.Constants.xlCenter
        xlWorkSheet.Range("D9").HorizontalAlignment = Excel.Constants.xlCenter
        xlWorkSheet.Range("D10:F10").HorizontalAlignment = Excel.Constants.xlCenter
        xlWorkSheet.Range("D11:D16").HorizontalAlignment = Excel.Constants.xlCenter
        xlWorkSheet.Range("E11:E13").HorizontalAlignment = Excel.Constants.xlCenter
        xlWorkSheet.Range("E14:E16").HorizontalAlignment = Excel.Constants.xlRight
        xlWorkSheet.Range("B17:F17").HorizontalAlignment = Excel.Constants.xlCenter
        xlWorkSheet.Range("B19:F19").HorizontalAlignment = Excel.Constants.xlCenter
        xlWorkSheet.Range("B20").HorizontalAlignment = Excel.Constants.xlCenter
        xlWorkSheet.Range("B21:F21").HorizontalAlignment = Excel.Constants.xlCenter
        xlWorkSheet.Range("B22:F22").HorizontalAlignment = Excel.Constants.xlCenter
        xlWorkSheet.Range("B23").HorizontalAlignment = Excel.Constants.xlCenter
        xlWorkSheet.Range("B24:F24").HorizontalAlignment = Excel.Constants.xlCenter
        ' Alinear el texto en el medio de la celda
        xlWorkSheet.Range("B2:F8").VerticalAlignment = Excel.XlVAlign.xlVAlignCenter
        xlWorkSheet.Range("B9:B16").VerticalAlignment = Excel.XlVAlign.xlVAlignCenter
        xlWorkSheet.Range("D9").VerticalAlignment = Excel.XlVAlign.xlVAlignCenter
        xlWorkSheet.Range("D10:F10").VerticalAlignment = Excel.XlVAlign.xlVAlignCenter
        xlWorkSheet.Range("D11:D16").VerticalAlignment = Excel.XlVAlign.xlVAlignCenter
        xlWorkSheet.Range("E11:E13").VerticalAlignment = Excel.XlVAlign.xlVAlignCenter
        xlWorkSheet.Range("D10:F10").VerticalAlignment = Excel.XlVAlign.xlVAlignCenter
        xlWorkSheet.Range("E14:E16").VerticalAlignment = Excel.XlVAlign.xlVAlignCenter
        xlWorkSheet.Range("B17:F17").VerticalAlignment = Excel.XlVAlign.xlVAlignCenter
        xlWorkSheet.Range("B19:F19").VerticalAlignment = Excel.XlVAlign.xlVAlignCenter
        xlWorkSheet.Range("B20:F24").VerticalAlignment = Excel.XlVAlign.xlVAlignCenter



        'LABELS DE LOS DATOS TIKETS
        xlWorkSheet.Range("B9:B16").HorizontalAlignment = Excel.XlHAlign.xlHAlignRight

        'LABELS TIPOS DE PAGO
        xlWorkSheet.Range("B20").Font.Color = Color.FromArgb(67, 116, 255)
        xlWorkSheet.Range("B23").Font.Color = Color.FromArgb(67, 116, 255)

        ' Autoajustar contenido
        ' Autoajustar el alto de la fila 1

        xlWorkSheet.Range("C11").WrapText = True
        xlWorkSheet.Range("C14").WrapText = True
        xlWorkSheet.Range("C15").WrapText = True
        xlWorkSheet.Range("E11").WrapText = True
        xlWorkSheet.Range("E12").WrapText = True
        xlWorkSheet.Range("B18:F18").WrapText = True
        'todos los bordes
        'xlWorkSheet.Range("A1:A4").Borders.LineStyle = Excel.XlLineStyle.xlContinuous
        'xlWorkSheet.Range("A1:A4").Borders.Weight = Excel.XlBorderWeight.xlThin

        'borde de arriba en una sola celda
        'xlWorkSheet.Range("C2").Borders.Item(Excel.XlBordersIndex.xlEdgeTop).LineStyle = Excel.XlLineStyle.xlContinuous
        'xlWorkSheet.Range("C2").Borders.Item(Excel.XlBordersIndex.xlEdgeTop).Weight = Excel.XlBorderWeight.xlThin

        'Borde de abajo en varias celdas
        'xlWorkSheet.Range("D1:D4").Borders.Item(Excel.XlBordersIndex.xlEdgeBottom).LineStyle = Excel.XlLineStyle.xlContinuous
        'xlWorkSheet.Range("D1:D4").Borders.Item(Excel.XlBordersIndex.xlEdgeBottom).Weight = Excel.XlBorderWeight.xlThin

        'Borde de izquierda en varias celdas
        'xlWorkSheet.Range("B2:B24").Borders.Item(Excel.XlBordersIndex.xlEdgeLeft).LineStyle = Excel.XlLineStyle.xlContinuous
        ' xlWorkSheet.Range("B2:B24").Borders.Item(Excel.XlBordersIndex.xlEdgeLeft).Weight = Excel.XlBorderWeight.xlThin
        'Borde de derecha en varias celdas
        'xlWorkSheet.Range("F2:F24").Borders.Item(Excel.XlBordersIndex.xlEdgeRight).LineStyle = Excel.XlLineStyle.xlContinuous
        'xlWorkSheet.Range("F2:F24").Borders.Item(Excel.XlBordersIndex.xlEdgeRight).Weight = Excel.XlBorderWeight.xlThin

        ' Guarda el libro de trabajo en la ruta especificada.

        'If File.Exists(TextBoxRuta.Text & "\Factura.xlsx") Then
        '    'Pregunta si el archivo exite para reemplazarlo y si no crea un archivo nuevo
        '    Dim result As Integer = MessageBox.Show("Este archivo ya exite. Quieres reemplazarlo?", "File Exists", MessageBoxButtons.YesNoCancel)
        '    If result = DialogResult.Yes Then
        '        'falta arreglar si el archivo esta en uso 
        '        File.Delete(TextBoxRuta.Text & "\Factura.xlsx")
        '        xlWorkBook.SaveAs(TextBoxRuta.Text & "\Factura.xlsx")
        '    ElseIf result = DialogResult.No Then
        '        Dim encotrado As Boolean = False
        '        ' Verifica si el archivo existe
        '        Dim i As Integer = 1
        '        'Si existe le pone el mism nombre pero con copia 
        '        While encotrado = False
        '            If File.Exists(TextBoxRuta.Text & "\Factura_Copia(" & i & ").xlsx") Then
        '            Else
        '                xlWorkBook.SaveAs(TextBoxRuta.Text & "\Factura_Copia(" & i & ").xlsx")

        '                encotrado = True
        '            End If
        '            i += 1
        '        End While
        '    End If
        'Else
        '    xlWorkBook.SaveAs(TextBoxRuta.Text & "\Factura.xlsx")
        'End If


        ' Guardar el documento en una ubicación fija
        Dim filePath As String = "C:\Users\edkac\Downloads\Factura.xlsx"
        xlWorkBook.SaveAs(filePath)

        ' Cerrar y liberar recursos
        xlWorkBook.Close()
        xlApp.Quit()
        releaseObject(xlWorkSheet)
        releaseObject(xlWorkBook)
        releaseObject(xlApp)

        MessageBox.Show("Archivo guardado con éxito.")

    End Sub
    Private Sub releaseObject(ByVal obj As Object)
        Try
            System.Runtime.InteropServices.Marshal.ReleaseComObject(obj)
            obj = Nothing
        Catch ex As Exception
            obj = Nothing
        Finally
            GC.Collect()
        End Try
    End Sub


End Class